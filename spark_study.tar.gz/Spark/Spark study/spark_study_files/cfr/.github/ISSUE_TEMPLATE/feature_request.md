---
name: Feature request
about: Suggest a feature for CFR.
title: ''
labels: enhancement
assignees: ''

---

<!-- Please have a look at `contributing.md`, to see which features will not be added -->
# Problem solved by this feature
<!-- Describe the problem the feature you are requesting tries to solve -->


# Feature description
<!-- Describe the feature -->


# Considerations
<!-- If applicable: Describe things which have to be considered when adding this feature -->


# Alternatives
<!-- Describe alternatives (if you can think of any) -->
