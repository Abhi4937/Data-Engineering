/*
 * Decompiled with CFR.
 */
package org.benf.cfr.tests;

public enum EnumTestEmpty {

}
