package org.benf.cfr.reader.bytecode.analysis.opgraph;

public interface IndexedStatement {
    InstrIndex getIndex();
}
