package org.benf.cfr.reader.bytecode.analysis.parse.utils;

public enum ReadWrite {
    READ,
    WRITE,
    READ_WRITE
}
