package org.benf.cfr.reader.bytecode.analysis.parse.rewriters;

public enum ExpressionRewriterFlags {
    RVALUE,
    LVALUE,
    LANDRVALUE
}
