package org.benf.cfr.reader.bytecode.analysis.parse.expression;

public interface LambdaExpressionCommon {
}
