package org.benf.cfr.reader.bytecode.opcode;

public abstract class OperationFactoryDupBase extends OperationFactoryDefault {
}
